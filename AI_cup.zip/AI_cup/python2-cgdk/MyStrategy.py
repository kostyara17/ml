from math import *
import math
from model.ActionType import ActionType
from model.HockeyistState import HockeyistState
from model.HockeyistType import HockeyistType
STRIKE_ANGLE = 1.0 * math.pi / 180.0;



class MyStrategy:
    def move(self, me, world, game, move):
        if me.state == HockeyistState.SWINGING:
            move.action = ActionType.STRIKE
        
        if world.puck.owner_player_id == me.player_id:
            if world.puck.owner_hockeyist_id == me.id:
                opponent_player = world.get_opponent_player()
    
                net_x = 0.5 * (opponent_player.net_back + opponent_player.net_front)
                net_y = 0.5 * (opponent_player.net_bottom + opponent_player.net_top)
                delta = 0.5 if me.y > net_y else -0.5
                net_y += delta * game.goal_net_height
                
                angle_to_net = me.get_angle_to(net_x, net_y)
                move.turn = angle_to_net
    
                if math.fabs(angle_to_net) < STRIKE_ANGLE:
                    move.action = ActionType.STRIKE
            else:
                nearest_opponent = get_nearest_opponent(me.x, me.y, world)
                if nearest_opponent is not None:
                    if me.get_distance_to_unit(nearest_opponent) > game.stick_length:
                        move.speed_up = 1.0
                    elif math.fabs(me.get_angle_to_unit(nearest_opponent)) < 0.5 * game.stick_sector:
                        move.action = ActionType.STRIKE
                    move.turn = me.get_angle_to_unit(nearest_opponent)
        else:
            move.speed_up = 1.0
            move.turn = me.get_angle_to_unit(world.puck)
            move.action = ActionType.TAKE_PUCK
            
            
def get_nearest_opponent(x, y, world):
    nearest_opponent = None
    nearest_opponent_range = 0.0

    for hockeyist in world.hockeyists:
        if hockeyist.teammate or hockeyist.type == HockeyistType.GOALIE or\
                hockeyist.state == HockeyistState.KNOCKED_DOWN or\
                hockeyist.state == HockeyistState.RESTING:
            continue;

        opponent_range = math.hypot(x - hockeyist.x, y - hockeyist.y)
        
        if nearest_opponent is None or opponent_range < nearest_opponent_range:
            nearest_opponent = hockeyist
            opponent_range = opponent_range;
    return nearest_opponent