class ActionType:
    NONE = 0
    TAKE_PUCK = 1
    SWING = 2
    STRIKE = 3
    CANCEL_STRIKE = 4
    PASS = 5
    SUBSTITUTE = 6