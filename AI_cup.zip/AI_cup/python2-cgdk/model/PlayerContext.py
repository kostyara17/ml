class PlayerContext:
    def __init__(self, hockeyists, world):
        self.hockeyists = hockeyists
        self.world = world