class HockeyistType:
    GOALIE = 0
    VERSATILE = 1
    FORWARD = 2
    DEFENCEMAN = 3
    RANDOM = 4