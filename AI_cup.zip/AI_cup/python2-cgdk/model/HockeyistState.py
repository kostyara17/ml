class HockeyistState:
    ACTIVE = 0
    SWINGING = 1
    KNOCKED_DOWN = 2
    RESTING = 3